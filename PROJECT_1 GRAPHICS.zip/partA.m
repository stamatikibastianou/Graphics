% ΜΕΡΟΣ Α: Σχεδιασμός "UOA"

% Προετοιμασία γραφήματος
figure(1);
hold on;
axis equal;
axis([0 120 -30 60]); % Όρια αξόνων για να φαίνεται σωστά
grid on;

% Χρώμα και πάχος γραμμής
color = 'k'; % Μαύρο
linewidth = 2;

% Σχεδιασμός Γράμματος U
% Κύκλοι για το U (Κέντρο (15,15) / Ακτίνες 15 και 5 / Μόνο 3ο & 4ο τεταρτημόριο)
[Cx1, Cy1] = bresenham_circle(15, 15, 15, [3, 4]);
[Cx2, Cy2] = bresenham_circle(15, 15, 5, [3, 4]);
plot(Cx1, Cy1, [color '.'], 'MarkerSize', 5);
plot(Cx2, Cy2, [color '.'], 'MarkerSize', 5);

% Ευθύγραμμα τμήματα για το U
lines_U = [
    0, 15, 0, 30;
    10, 15, 10, 30;
    20, 15, 20, 30;
    30, 15, 30, 30;
    0, 30, 10, 30;
    20, 30, 30, 30
];

for i = 1:size(lines_U, 1)
    [lx, ly] = bresenham_line(lines_U(i,1), lines_U(i,2), lines_U(i,3), lines_U(i,4));
    plot(lx, ly, [color '.'], 'MarkerSize', 5);
end


% Σχεδιασμός Γράμματος O
% Κύκλοι για το O (Κέντρο (55,15) / Ακτίνες 15 και 7 / Όλα τα τεταρτημόρια)
[Ox1, Oy1] = bresenham_circle(55, 15, 15, [1, 2, 3, 4]);
[Ox2, Oy2] = bresenham_circle(55, 15, 7, [1, 2, 3, 4]);
plot(Ox1, Oy1, [color '.'], 'MarkerSize', 5);
plot(Ox2, Oy2, [color '.'], 'MarkerSize', 5);


% Σχεδιασμός Γράμματος A
% Ευθύγραμμα τμήματα για το A
lines_A = [
    103, 17, 102, 25;
    97, 25, 95, 17;
    97, 25, 102, 25;
    95, 17, 103, 17;
    90, 30, 108, 30;
    118, 0, 108, 30;
    80, 0, 90, 30;
    108, 0, 118, 0;
    108, 0, 104, 12;
    94, 12, 104, 12;
    94, 12, 90, 0;
    80, 0, 90, 0
];

for i = 1:size(lines_A, 1)
    [lx, ly] = bresenham_line(lines_A(i,1), lines_A(i,2), lines_A(i,3), lines_A(i,4));
    plot(lx, ly, [color '.'], 'MarkerSize', 5);
end

title('ΜΕΡΟΣ Α: UOA (Bresenham)');
hold off;
