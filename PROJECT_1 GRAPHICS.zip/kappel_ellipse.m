function [X, Y] = kappel_ellipse(xc, yc, a, b, quads)
    % Αν δεν δώσω συγκεκριμένα τεταρτημόρια, ζωγράφισέ τα όλα
    if nargin < 5
        quads = [1, 2, 3, 4];
    end

    X = [];
    Y = [];

    % Αρχικοποίηση
    x = 0;
    y = b;
    a2 = a^2;
    b2 = b^2;

    % Μεταβλητές dx, dy
    dx = 2 * b2 * x;
    dy = 2 * a2 * y;

    % ΠΕΡΙΟΧΗ 1
    % Αρχικό σφάλμα Περιοχής 1
    f_mid1 = b2 - a2*b + 0.25*a2;

    while dx < dy
        % Αποθήκευση συμμετρικών σημείων
        [X, Y] = add_ellipse_points(X, Y, x, y, xc, yc, quads);

        if f_mid1 < 0
            x = x + 1;
            dx = dx + 2*b2;
            f_mid1 = f_mid1 + dx + b2;
        else
            x = x + 1;
            y = y - 1;
            dx = dx + 2*b2;
            dy = dy - 2*a2;
            f_mid1 = f_mid1 + dx - dy + b2;
        end
    end

    % ΠΕΡΙΟΧΗ 2
    % Αρχικό σφάλμα Περιοχής 2 (ξεκινάει από το τελευταίο x, y της Περιοχής 1)
    f_mid2 = b2*(x + 0.5)^2 + a2*(y - 1)^2 - a2*b2;

    while y >= 0
        % Αποθήκευση συμμετρικών σημείων
        [X, Y] = add_ellipse_points(X, Y, x, y, xc, yc, quads);

        if f_mid2 > 0
            y = y - 1;
            dy = dy - 2*a2;
            f_mid2 = f_mid2 - dy + a2;
        else
            y = y - 1;
            x = x + 1;
            dx = dx + 2*b2;
            dy = dy - 2*a2;
            f_mid2 = f_mid2 + dx - dy + a2;
        end
    end
end

% Βοηθητική συνάρτηση συμμετρίας (μόνο 4 δρόμοι)
function [X, Y] = add_ellipse_points(X, Y, x, y, xc, yc, quads)
    pts = [ x,  y;   % 1ο τεταρτημόριο
           -x,  y;   % 2ο τεταρτημόριο
           -x, -y;   % 3ο τεταρτημόριο
            x, -y];  % 4ο τεταρτημόριο

    for i = 1:4
        px = pts(i, 1);
        py = pts(i, 2);

        q = 0;
        if px >= 0 && py >= 0
            q = 1;
        elseif px < 0 && py >= 0
            q = 2;
        elseif px < 0 && py < 0
            q = 3;
        elseif px >= 0 && py < 0
            q = 4;
        end

        % Αν το τεταρτημόριο είναι σε αυτά που ζητήθηκαν, το κρατάμε
        if ismember(q, quads)
            X = [X, px + xc];
            Y = [Y, py + yc];
        end
    end
end
