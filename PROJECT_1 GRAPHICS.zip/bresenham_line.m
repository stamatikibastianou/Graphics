function [X, Y] = bresenham_line(x1, y1, x2, y2)
    % Εξασφαλίζουμε ότι τα σημεία είναι ακέραιοι
    x1 = round(x1); y1 = round(y1);
    x2 = round(x2); y2 = round(y2);

    % Υπολογισμός διαφορών
    dx = abs(x2 - x1);
    dy = abs(y2 - y1);

    % Υπολογισμός κατεύθυνσης
    sx = sign(x2 - x1);
    sy = sign(y2 - y1);

    % Έλεγχος κλίσης
    steep = (dy > dx);

    if steep
        % Αντιμετάθεση αν είναι απότομη
        temp = x1; x1 = y1; y1 = temp;
        temp = dx; dx = dy; dy = temp;
        temp = sx; sx = sy; sy = temp;
    end

    % Αρχικό σφάλμα
    e = 2*dy - dx;
    x = x1;
    y = y1;

    % Πίνακες για να αποθηκεύσουμε τα σημεία
    n = dx + 1;
    X = zeros(1, n);
    Y = zeros(1, n);

    % Η κεντρική λούπα του αλγορίθμου
    for i = 1:n
        if steep
            X(i) = y;   % Επαναφορά συμμετρίας
            Y(i) = x;
        else
            X(i) = x;
            Y(i) = y;
        end

        % Έλεγχος σφάλματος
        if e >= 0
            y = y + sy;
            e = e - 2*dx;
        end
        x = x + sx;
        e = e + 2*dy;
    end
end
